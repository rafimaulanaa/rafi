import React, { useState, useMemo } from 'react';

const App = () => {
    const [searchTerm, setSearchTerm] = useState('');

    const skincareItems = useMemo(() => [
        { id: 1, name: 'Cleanser', brand: 'Brand A' },
        { id: 2, name: 'Toner', brand: 'Brand B' },
        { id: 3, name: 'Serum', brand: 'Brand C' },
        { id: 4, name: 'Moisturizer', brand: 'Brand D' },
        { id: 5, name: 'Sunscreen', brand: 'Brand E' },
        { id: 6, name: 'Eye Cream', brand: 'Brand F' },
        { id: 7, name: 'Face Oil', brand: 'Brand G' },
        { id: 8, name: 'Exfoliator', brand: 'Brand H' },
        { id: 9, name: 'Essence', brand: 'Brand I' },
        { id: 10, name: 'Ampoule', brand: 'Brand J' },
        { id: 11, name: 'Sheet Mask', brand: 'Brand K' },
        { id: 12, name: 'Clay Mask', brand: 'Brand L' },
        { id: 13, name: 'Sleeping Mask', brand: 'Brand M' },
        { id: 14, name: 'Face Mist', brand: 'Brand N' },
        { id: 15, name: 'Lip Balm', brand: 'Brand O' },
        { id: 16, name: 'Lip Scrub', brand: 'Brand P' },
        { id: 17, name: 'Micellar Water', brand: 'Brand Q' },
        { id: 18, name: 'Makeup Remover', brand: 'Brand R' },
        { id: 19, name: 'Facial Foam', brand: 'Brand S' },
        { id: 20, name: 'Facial Gel', brand: 'Brand T' },
        { id: 21, name: 'Peeling Gel', brand: 'Brand U' },
        { id: 22, name: 'Face Wash', brand: 'Brand V' },
        { id: 23, name: 'Whitening Cream', brand: 'Brand W' },
        { id: 24, name: 'Anti Aging Cream', brand: 'Brand X' },
        { id: 25, name: 'Pore Minimizer', brand: 'Brand Y' },
        { id: 26, name: 'Hydrating Lotion', brand: 'Brand Z' },
        { id: 27, name: 'BB Cream', brand: 'Brand AA' },
        { id: 28, name: 'CC Cream', brand: 'Brand BB' },
        { id: 29, name: 'Primer', brand: 'Brand CC' },
        { id: 30, name: 'Concealer', brand: 'Brand DD' },
    ], []);

    const filteredItems = useMemo(() => {
        return skincareItems.filter(item =>
            item.name.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }, [searchTerm, skincareItems]);

    return (
        <div className="App">
            <h1>Daftar Skincare</h1>
            <input
                type="text"
                placeholder="Cari skincare..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            <ul>
                {filteredItems.map(item => (
                    <li key={item.id}>
                        {item.name} - {item.brand}
                    </li>
                ))}
            </ul>
            <style jsx>{`
                .App {
                    text-align: center;
                    font-family: Arial, sans-serif;
                    background-color: #f9f9f9;
                    padding: 20px;
                }

                h1 {
                    color: #333;
                }

                input {
                    margin: 10px 0;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    width: 300px;
                }

                ul {
                    list-style-type: none;
                    padding: 0;
                    max-width: 600px;
                    margin: 0 auto;
                }

                li {
                    margin: 10px 0;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    background-color: #fff;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                    transition: transform 0.2s;
                }

                li:hover {
                    transform: scale(1.02);
                }
            `}</style>
        </div>
    );
};

export default App;
